export const PORT = 3000;

export const DB_URL = "mongodb+srv://aditya:root123@cluster0.959cw0a.mongodb.net/crud?retryWrites=true&w=majority&appName=Cluster0"